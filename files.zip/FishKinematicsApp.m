function FishKinematicsApp()
% FISHKINEMATICSAPP  Interactive UI for fish midline kinematics analysis.
%
%   Supports two CSV formats:
%     FORMAT A (DLC-style): columns Fish1_P1_x, Fish1_P1_y[, Fish1_P1_z] ...
%     FORMAT B (named):     columns eye_X, eye_Y[, eye_Z], snout_X ...
%
%   For Format B the user selects, orders, and optionally averages points
%   before running the analysis.
%
%   REQUIRES: load_fish_points.m, load_fish_points_named.m,
%             transform_fish.m, compute_kinematics.m

    %% ---- Shared state ----
    app.fp        = [];
    app.kine      = [];
    app.fmt       = '';       % 'DLC' or 'named'
    app.avail_pts = {};       % point base-names available in the file
    app.sel_order = {};       % ordered list of selected entries (strings or 2-cell avg pairs)

    %% ---- Figure ----
    fig = uifigure('Name',     'Fish Kinematics Analyser', ...
                   'Position', [60 40 1200 780], ...
                   'Color',    [0.95 0.95 0.95]);

    %% ================================================================
    %  LEFT PANEL  (inputs, point selector, results)
    %% ================================================================
    LP = uipanel(fig, 'Position', [10 10 340 760], ...
                 'BackgroundColor', [1 1 1], 'BorderType', 'line', 'Title', '');

    y = 728;   % running y cursor (top → bottom)

    % ---- File ----
    y = section_label(LP, 'INPUT FILE', y);
    app.fileField = uieditfield(LP, 'text', ...
        'Position', [12 y-26 240 26], 'Placeholder', 'No file selected', 'Editable', 'off');
    uibutton(LP, 'Text', 'Browse…', 'Position', [258 y-26 70 26], ...
        'ButtonPushedFcn', @(~,~) onBrowse());
    y = y - 40;

    % ---- Format indicator ----
    app.fmtLabel = uilabel(LP, 'Text', '', ...
        'Position', [12 y-20 316 20], 'FontSize', 11, 'FontColor', [0.3 0.5 0.8]);
    y = y - 32;

    % ---- Parameters ----
    y = section_label(LP, 'PARAMETERS', y);
    uilabel(LP, 'Text', 'Frames per second', 'Position', [12 y-24 190 20], 'FontSize', 12);
    app.fpsField = uieditfield(LP, 'numeric', 'Position', [250 y-24 78 26], ...
        'Value', 100, 'Limits', [1 1e5]);
    y = y - 30;
    uilabel(LP, 'Text', 'Min frequency (Hz)', 'Position', [12 y-24 190 20], 'FontSize', 12);
    app.minFreqField = uieditfield(LP, 'numeric', 'Position', [250 y-24 78 26], ...
        'Value', 0.5, 'Limits', [0 1000]);
    y = y - 42;

    % ---- Point selector (shown only for Format B) ----
    app.ptPanel = uipanel(LP, 'Position', [8 y-210 324 210], ...
        'BackgroundColor', [0.97 0.97 1], 'BorderType', 'line', 'Title', 'Point Selection');
    app.ptPanel.Visible = 'off';

    % Available points list (left)
    uilabel(app.ptPanel, 'Text', 'Available', ...
        'Position', [4 162 90 18], 'FontSize', 10, 'FontWeight', 'bold', 'FontColor', [0.4 0.4 0.4]);
    app.availList = uilistbox(app.ptPanel, 'Position', [4 4 130 158], ...
        'Multiselect', 'on', 'Items', {});

    % Buttons (middle)
    uibutton(app.ptPanel, 'Text', '→ Add', 'Position', [140 140 70 24], ...
        'ButtonPushedFcn', @(~,~) onAddPoint());
    uibutton(app.ptPanel, 'Text', '⇌ Avg', 'Position', [140 112 70 24], ...
        'ButtonPushedFcn', @(~,~) onAddAvg());
    uibutton(app.ptPanel, 'Text', '↑ Up',  'Position', [140 80 70 24], ...
        'ButtonPushedFcn', @(~,~) onMoveUp());
    uibutton(app.ptPanel, 'Text', '↓ Down','Position', [140 56 70 24], ...
        'ButtonPushedFcn', @(~,~) onMoveDown());
    uibutton(app.ptPanel, 'Text', '✕ Remove','Position', [140 28 70 24], ...
        'ButtonPushedFcn', @(~,~) onRemovePoint());
    uibutton(app.ptPanel, 'Text', 'Clear', 'Position', [140 4 70 24], ...
        'ButtonPushedFcn', @(~,~) onClearPoints());

    % Selected / ordered points list (right)
    uilabel(app.ptPanel, 'Text', 'Selected (head → tail)', ...
        'Position', [216 162 110 18], 'FontSize', 10, 'FontWeight', 'bold', 'FontColor', [0.4 0.4 0.4]);
    app.selList = uilistbox(app.ptPanel, 'Position', [216 4 100 158], ...
        'Multiselect', 'on', 'Items', {});

    y = y - 218;

    % ---- Run button ----
    y = y - 4;
    app.runBtn = uibutton(LP, 'Text', 'Load & Analyse', ...
        'Position', [12 y-36 316 36], 'FontSize', 13, 'FontWeight', 'bold', ...
        'BackgroundColor', [0.18 0.42 0.75], 'FontColor', [1 1 1], ...
        'ButtonPushedFcn', @(~,~) onRun());
    y = y - 44;

    % Status
    app.statusLabel = uilabel(LP, 'Text', 'Load a CSV file to begin.', ...
        'Position', [12 y-20 316 20], 'FontSize', 11, 'FontColor', [0.4 0.4 0.4], 'WordWrap', 'on');
    y = y - 30;

    % ---- Animal / fish selector ----
    y = section_label(LP, 'SELECT ANIMAL', y);
    app.fishList = uilistbox(LP, 'Position', [12 y-70 316 68], ...
        'Items', {'(run analysis first)'}, 'ValueChangedFcn', @(~,~) onFishSelected());
    y = y - 78;

    % ---- Results ----
    y = section_label(LP, 'KINEMATIC VALUES', y);
    app.resultsArea = uitextarea(LP, 'Position', [12 10 316 y-14], ...
        'Editable', 'off', 'FontSize', 11, 'FontName', 'Courier New', ...
        'BackgroundColor', [0.97 0.97 0.97], 'Value', {''});

    %% ================================================================
    %  RIGHT PANEL  — 2×2 plots
    %% ================================================================
    titles = {'Midlines (FFT interpolated)', 'Amplitude envelope', ...
              'Curvature profile',           'Beat frequency spectra'};
    pos    = {[360 410 400 340]; [770 410 400 340]; [360 50 400 340]; [770 50 400 340]};

    app.ax = gobjects(4,1);
    for i = 1:4
        app.ax(i) = uiaxes(fig, 'Position', pos{i}, 'BackgroundColor', [1 1 1], 'Box', 'on');
        title(app.ax(i), titles{i}, 'FontSize', 11);
        app.ax(i).Toolbar.Visible = 'off';
    end
    xlabel(app.ax(1),'X (BL)');               ylabel(app.ax(1),'Y (BL)');
    xlabel(app.ax(2),'Body pos (0=head,1=tail)'); ylabel(app.ax(2),'Half-amp (BL)');
    xlabel(app.ax(3),'Body pos (0=head,1=tail)'); ylabel(app.ax(3),'Curvature (1/BL)');
    xlabel(app.ax(4),'Frequency (Hz)');        ylabel(app.ax(4),'Power');
    for i = 1:4
        text(app.ax(i), 0.5, 0.5, 'No data', 'Units', 'normalized', ...
             'HorizontalAlignment', 'center', 'FontSize', 12, 'Color', [0.75 0.75 0.75]);
    end

    %% ================================================================
    %  CALLBACKS
    %% ================================================================

    % ---- Browse ----
    function onBrowse()
        [fn, fp_] = uigetfile('*.csv', 'Select tracking CSV');
        if isequal(fn, 0), return; end
        fullpath = fullfile(fp_, fn);
        app.fileField.Value = fullpath;
        detectFormat(fullpath);
    end

    % ---- Detect format from file ----
    function detectFormat(path)
        opts = detectImportOptions(path);
        opts.VariableNamingRule = 'preserve';
        T = readtable(path, opts);
        cols = T.Properties.VariableNames;

        dlc_match = ~cellfun(@isempty, regexp(cols, '^Fish\d+_P\d+_[xyXY]'));
        if any(dlc_match)
            app.fmt = 'DLC';
            app.fmtLabel.Text = 'Format: DLC  (Fish1_P1_x columns)';
            app.ptPanel.Visible = 'off';
        else
            app.fmt = 'named';
            app.fmtLabel.Text = 'Format: Named  (eye_X, snout_Y … columns)';
            app.ptPanel.Visible = 'on';
            % Populate available-points list
            tok = regexp(cols, '^(.+)_[Xx]$', 'tokens');
            bases = cellfun(@(t) t{1}{1}, tok(~cellfun(@isempty,tok)), 'UniformOutput', false);
            app.avail_pts = bases;
            app.availList.Items = bases;
            app.sel_order = {};
            app.selList.Items = {};
        end
    end

    % ---- Add selected available point(s) ----
    function onAddPoint()
        sel = app.availList.Value;
        if ischar(sel), sel = {sel}; end
        for k = 1:numel(sel)
            if ~any(strcmp(entry_label(sel{k}), app.selList.Items))
                app.sel_order{end+1} = sel{k};
            end
        end
        refreshSelList();
    end

    % ---- Add averaged pair ----
    function onAddAvg()
        sel = app.availList.Value;
        if ischar(sel), sel = {sel}; end
        if numel(sel) < 2
            uialert(fig, 'Select exactly 2 points to average.', 'Average'); return
        end
        pair = sel(1:2);
        lbl  = strjoin(pair, '+');
        if ~any(strcmp(lbl, app.selList.Items))
            app.sel_order{end+1} = pair;
        end
        refreshSelList();
    end

    % ---- Move up/down ----
    function onMoveUp()
        idx = getSelListIdx();
        if isempty(idx) || idx == 1, return; end
        app.sel_order([idx-1 idx]) = app.sel_order([idx idx-1]);
        refreshSelList();
        app.selList.Value = app.selList.Items{idx-1};
    end
    function onMoveDown()
        idx = getSelListIdx();
        if isempty(idx) || idx == numel(app.sel_order), return; end
        app.sel_order([idx idx+1]) = app.sel_order([idx+1 idx]);
        refreshSelList();
        app.selList.Value = app.selList.Items{idx+1};
    end

    % ---- Remove ----
    function onRemovePoint()
        idx = getSelListIdx();
        if isempty(idx), return; end
        app.sel_order(idx) = [];
        refreshSelList();
    end
    function onClearPoints()
        app.sel_order = {};
        refreshSelList();
    end

    % ---- Helpers ----
    function refreshSelList()
        lbls = cellfun(@entry_label, app.sel_order, 'UniformOutput', false);
        app.selList.Items = lbls;
    end
    function lbl = entry_label(e)
        if iscell(e), lbl = strjoin(e, '+'); else, lbl = e; end
    end
    function idx = getSelListIdx()
        val = app.selList.Value;
        idx = find(strcmp(val, app.selList.Items), 1);
    end

    % ---- Run ----
    function onRun()
        csvPath = strtrim(app.fileField.Value);
        if isempty(csvPath) || ~isfile(csvPath)
            uialert(fig, 'Select a valid CSV file first.', 'No file'); return
        end
        fps     = app.fpsField.Value;
        minFreq = app.minFreqField.Value;

        setStatus('Loading…');

        try
            if strcmp(app.fmt, 'DLC')
                app.fp = load_fish_points(csvPath);
            else
                if numel(app.sel_order) < 3
                    uialert(fig, 'Select at least 3 points (head, middle(s), tail).', 'Points'); return
                end
                app.fp = load_fish_points_named(csvPath, app.sel_order, []);
                app.fp = app.fp(1);   % named loader always returns 1 animal
            end
        catch ME; uialert(fig, ME.message, 'Load error'); setStatus('Load failed.'); return; end

        setStatus('Transforming…');
        try
            app.fp = transform_fish(app.fp);
        catch ME; uialert(fig, ME.message, 'Transform error'); setStatus('Failed.'); return; end

        setStatus('Computing kinematics…');
        try
            app.kine = compute_kinematics(app.fp, fps, minFreq);
        catch ME; uialert(fig, ME.message, 'Kinematics error'); setStatus('Failed.'); return; end

        names = {app.kine.name};
        app.fishList.Items = names;
        app.fishList.Value = names{1};
        setStatus(sprintf('Done. %d animal(s) analysed.', numel(app.kine)));
        onFishSelected();
    end

    % ---- Fish/animal selected ----
    function onFishSelected()
        if isempty(app.kine), return; end
        names = {app.kine.name};
        fi    = find(strcmp(app.fishList.Value, names), 1);
        if isempty(fi), return; end

        k  = app.kine(fi);
        fp = app.fp(fi);
        has_z = isfield(fp, 'has_z') && fp.has_z;

        % -- Results text --
        L = {};
        L{end+1} = sprintf('Animal:             %s', k.name);
        L{end+1} = repmat('-',1,34);
        L{end+1} = sprintf('Head TBF:           %.3f Hz',  k.head_TBF);
        L{end+1} = sprintf('Tail TBF:           %.3f Hz',  k.tail_TBF);
        if has_z
        L{end+1} = sprintf('Head TBF (Z):       %.3f Hz',  k.headZ_TBF);
        L{end+1} = sprintf('Tail TBF (Z):       %.3f Hz',  k.tailZ_TBF);
        end
        L{end+1} = repmat('-',1,34);
        L{end+1} = sprintf('Head amp (Y):       %.4f BL',  k.headAmp);
        L{end+1} = sprintf('Tail amp (Y):       %.4f BL',  k.tailAmp);
        L{end+1} = sprintf('Head/tail ratio:    %.4f',     k.headTailAmpRatio);
        L{end+1} = sprintf('Min amp (Y):        %.4f BL @ %.3f', k.minAmp, k.minAmpLoc);
        L{end+1} = sprintf('Max amp (Y):        %.4f BL @ %.3f', k.maxAmp, k.maxAmpLoc);
        if has_z
        L{end+1} = repmat('-',1,34);
        L{end+1} = sprintf('Head amp (Z):       %.4f',     k.headAmpZ);
        L{end+1} = sprintf('Tail amp (Z):       %.4f',     k.tailAmpZ);
        L{end+1} = sprintf('Min amp (Z):        %.4f @ %.3f', k.minAmpZ, k.minAmpZLoc);
        L{end+1} = sprintf('Max amp (Z):        %.4f @ %.3f', k.maxAmpZ, k.maxAmpZLoc);
        end
        L{end+1} = repmat('-',1,34);
        L{end+1} = sprintf('Wavelength:         %.4f BL',  k.wavelength);
        L{end+1} = repmat('-',1,34);
        L{end+1} = sprintf('Max curv (XY):      %.4f @ %.3f', k.maxCurv, k.maxCurvLoc);
        if has_z
        L{end+1} = sprintf('Max curv (3D):      %.4f @ %.3f', k.maxCurv3D, k.maxCurv3DLoc);
        end
        app.resultsArea.Value = L;

        % -- Plot 1: Midlines --
        cla(app.ax(1));
        valid = find(~any(isnan(k.Y_interp), 2));
        if ~isempty(valid)
            cmap = parula(numel(valid));
            hold(app.ax(1),'on');
            yline(app.ax(1), 0, 'k--', 'LineWidth', 0.8);
            step = max(1, floor(numel(valid)/40));
            for ii = 1:step:numel(valid)
                f = valid(ii);
                plot(app.ax(1), k.X_interp(f,:), k.Y_interp(f,:), ...
                     'Color', [cmap(ii,:) 0.4], 'LineWidth', 0.8);
            end
            mf = valid(round(end/2));
            scatter(app.ax(1), fp.X(mf,:), fp.Y(mf,:), 40, 'r', 'filled');
            hold(app.ax(1),'off');
        end

        % -- Plot 2: Amplitude envelope (Y; Z overlaid if 3D) --
        cla(app.ax(2)); hold(app.ax(2),'on');
        s = k.s_norm;
        fill(app.ax(2), [s fliplr(s)], [k.amp_mean+k.amp_std fliplr(k.amp_mean-k.amp_std)], ...
             [0.6 0.8 1], 'EdgeColor','none','FaceAlpha',0.4);
        plot(app.ax(2), s, k.amp_mean, 'b-', 'LineWidth', 2, 'DisplayName','Y amp');
        if has_z && ~isempty(k.ampZ_mean)
            fill(app.ax(2), [s fliplr(s)], [k.ampZ_mean+k.ampZ_std fliplr(k.ampZ_mean-k.ampZ_std)], ...
                 [1 0.75 0.6], 'EdgeColor','none','FaceAlpha',0.3);
            plot(app.ax(2), s, k.ampZ_mean, 'r-', 'LineWidth', 2, 'DisplayName','Z amp');
        end
        xline(app.ax(2), k.minAmpLoc, 'b:'); xline(app.ax(2), k.maxAmpLoc, 'b--');
        legend(app.ax(2), 'Location','northwest','FontSize',9);
        hold(app.ax(2),'off'); xlim(app.ax(2),[0 1]);

        % -- Plot 3: Curvature (XY; 3D overlaid) --
        cla(app.ax(3)); hold(app.ax(3),'on');
        fill(app.ax(3), [s fliplr(s)], [k.curv_mean+k.curv_std fliplr(k.curv_mean-k.curv_std)], ...
             [1 0.8 0.7], 'EdgeColor','none','FaceAlpha',0.4);
        plot(app.ax(3), s, k.curv_mean, 'r-', 'LineWidth', 2, 'DisplayName','XY curv');
        if has_z && ~isempty(k.curv3d_mean)
            plot(app.ax(3), s, k.curv3d_mean, 'm--', 'LineWidth', 1.5, 'DisplayName','3D curv');
        end
        xline(app.ax(3), k.maxCurvLoc, 'k--');
        legend(app.ax(3), 'Location','northwest','FontSize',9);
        hold(app.ax(3),'off'); xlim(app.ax(3),[0 1]);

        % -- Plot 4: FFT spectra --
        cla(app.ax(4)); hold(app.ax(4),'on');
        plot(app.ax(4), k.head_fft_freq, k.head_fft_power, 'b-', 'LineWidth',1.2, ...
             'DisplayName', sprintf('Head Y (%.2fHz)', k.head_TBF));
        plot(app.ax(4), k.tail_fft_freq, k.tail_fft_power, 'r-', 'LineWidth',1.2, ...
             'DisplayName', sprintf('Tail Y (%.2fHz)', k.tail_TBF));
        xline(app.ax(4), k.head_TBF, 'b--', 'LineWidth',1);
        xline(app.ax(4), k.tail_TBF, 'r--', 'LineWidth',1);
        legend(app.ax(4),'Location','northeast','FontSize',9);
        hold(app.ax(4),'off');
    end

    function setStatus(msg)
        app.statusLabel.Text = msg; drawnow;
    end

    %% ================================================================
    %  LAYOUT HELPERS
    %% ================================================================
    function y_out = section_label(parent, txt, y_in)
        uilabel(parent, 'Text', txt, 'Position', [12 y_in-18 316 18], ...
                'FontSize', 10, 'FontWeight', 'bold', 'FontColor', [0.5 0.5 0.5]);
        y_out = y_in - 24;
    end

end
